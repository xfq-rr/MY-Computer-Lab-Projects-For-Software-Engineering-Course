import type { PropsWithChildren } from 'react';
import { ThemeProvider } from '@/store/themeStore';
import { CourseProvider } from '@/store/courseStore';
// 全局样式
import './app.scss';

function App({ children }: PropsWithChildren) {
  return (
    <ThemeProvider>
      <CourseProvider>{children}</CourseProvider>
    </ThemeProvider>
  );
}

export default App;
