export default definePageConfig({
  navigationBarTitleText: '今日签到',
  enablePullDownRefresh: false,
  backgroundTextStyle: 'light'
});
