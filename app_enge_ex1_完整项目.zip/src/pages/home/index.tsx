import React, { useState } from 'react';
import { View, Text, Button } from '@tarojs/components';
import Taro from '@tarojs/taro';
import dayjs from 'dayjs';
import classnames from 'classnames';
import styles from './index.module.scss';
import { useCourseStore } from '@/store/courseStore';
import { useThemeStore } from '@/store/themeStore';
import type { SessionStatus } from '@/types/course';

const WEEKS = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
const WEEKDAY_SHORT = ['日', '一', '二', '三', '四', '五', '六'];

function formatWeekdays(weekdays: number[]): string {
  return weekdays
    .slice()
    .sort((a, b) => a - b)
    .map(w => `周${WEEKDAY_SHORT[w]}`)
    .join(' · ');
}

const HomePage: React.FC = () => {
  const { todayList, pendingCount, performCheckin } = useCourseStore();
  const { themeStyle } = useThemeStore();
  const [submittingId, setSubmittingId] = useState<string | null>(null);

  const today = dayjs();
  const dateLabel = today.format('YYYY年 M月 D日');
  const weekLabel = WEEKS[today.day()];

  const handleSign = async (courseId: string) => {
    if (submittingId) return;
    setSubmittingId(courseId);
    try {
      const result = performCheckin(courseId);
      Taro.showToast({
        title: result.message,
        icon: result.success ? 'success' : 'none'
      });
    } catch (err) {
      console.error('[Home] 签到异常', err);
      Taro.showToast({ title: '签到失败，请稍后再试', icon: 'none' });
    } finally {
      setSubmittingId(null);
    }
  };

  const renderStatus = (courseId: string, status: SessionStatus) => {
    if (status === 'checked') {
      return (
        <View className={classnames(styles.badge, styles.badgeChecked)}>
          <Text className={classnames(styles.badgeText, styles.badgeTextChecked)}>
            已签到 ✓
          </Text>
        </View>
      );
    }
    if (status === 'missed') {
      return (
        <View className={classnames(styles.badge, styles.badgeMissed)}>
          <Text className={classnames(styles.badgeText, styles.badgeTextMissed)}>漏签</Text>
        </View>
      );
    }
    return (
      <Button
        className={styles.signButton}
        loading={submittingId === courseId}
        disabled={submittingId !== null}
        onClick={() => handleSign(courseId)}
      >
        <Text className={styles.signButtonText}>签到</Text>
      </Button>
    );
  };

  return (
    <View className={styles.page} style={themeStyle}>
      <View className={styles.hero}>
        <Text className={styles.heroDate}>{dateLabel} · {weekLabel}</Text>
        <Text className={styles.heroTitle}>今日课程签到</Text>
        <View className={styles.heroStatus}>
          <View className={styles.heroStatusDot} />
          <Text className={styles.heroStatusText}>
            {todayList.length === 0
              ? '今天没有安排课程'
              : pendingCount > 0
                ? `今天还有 ${pendingCount} 门课程待签到`
                : '今天的课程已全部签到完成 🎉'}
          </Text>
        </View>
      </View>

      <Text className={styles.sectionTitle}>今日课程（{todayList.length}）</Text>

      {todayList.length === 0 ? (
        <View className={styles.empty}>
          <Text className={styles.emptyIcon}>📚</Text>
          <Text className={styles.emptyText}>今天没有需要签到的课程</Text>
        </View>
      ) : (
        <View className={styles.list}>
          {todayList.map(({ course, status }) => (
            <View key={course.id} className={styles.courseCard}>
              <View className={styles.courseInfo}>
                <Text className={styles.courseName}>{course.name}</Text>
                <Text className={styles.courseMeta}>
                  {course.teacher} · {course.location}
                </Text>
                <Text className={styles.courseMeta}>{formatWeekdays(course.weekdays)}</Text>
                <Text className={styles.deadline}>
                  每日 {course.deadline} 前签到
                </Text>
              </View>
              <View className={styles.action}>{renderStatus(course.id, status)}</View>
            </View>
          ))}
        </View>
      )}
    </View>
  );
};

export default HomePage;
