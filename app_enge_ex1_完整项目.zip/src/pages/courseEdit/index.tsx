import React, { useState } from 'react';
import { View, Text, Input, Button, Picker } from '@tarojs/components';
import Taro from '@tarojs/taro';
import classnames from 'classnames';
import styles from './index.module.scss';
import { useCourseStore } from '@/store/courseStore';
import { useThemeStore } from '@/store/themeStore';
import BackButton from '@/components/BackButton';

const WEEKDAYS = [
  { value: 1, label: '周一' },
  { value: 2, label: '周二' },
  { value: 3, label: '周三' },
  { value: 4, label: '周四' },
  { value: 5, label: '周五' },
  { value: 6, label: '周六' },
  { value: 0, label: '周日' }
];

const CourseEditPage: React.FC = () => {
  const { addCourse } = useCourseStore();
  const { themeStyle } = useThemeStore();

  const [name, setName] = useState('');
  const [teacher, setTeacher] = useState('');
  const [location, setLocation] = useState('');
  const [weekdays, setWeekdays] = useState<number[]>([]);
  const [deadline, setDeadline] = useState('23:59');
  const [saving, setSaving] = useState(false);

  const toggleWeekday = (value: number) => {
    setWeekdays(prev =>
      prev.includes(value) ? prev.filter(w => w !== value) : [...prev, value]
    );
  };

  const handleSave = () => {
    const trimmedName = name.trim();
    if (!trimmedName) {
      Taro.showToast({ title: '请输入课程名称', icon: 'none' });
      return;
    }
    if (weekdays.length === 0) {
      Taro.showToast({ title: '请至少选择一个上课日', icon: 'none' });
      return;
    }
    if (!deadline) {
      Taro.showToast({ title: '请选择签到截止时间', icon: 'none' });
      return;
    }

    setSaving(true);
    try {
      addCourse({
        name: trimmedName,
        teacher: teacher.trim() || '未填写',
        location: location.trim() || '未填写',
        weekdays: weekdays.slice().sort((a, b) => a - b),
        deadline
      });
      Taro.showToast({ title: '添加成功', icon: 'success' });
      setTimeout(() => {
        Taro.navigateBack();
      }, 600);
    } catch (err) {
      console.error('[CourseEdit] 添加课程失败', err);
      Taro.showToast({ title: '添加失败，请重试', icon: 'none' });
      setSaving(false);
    }
  };

  return (
    <View className={styles.page} style={themeStyle}>
      <BackButton fallbackUrl="/pages/mine/index" />
      <View className={styles.section}>
        <View className={styles.field}>
          <Text className={styles.fieldLabel}>课程名称</Text>
          <Input
            className={styles.fieldInput}
            placeholder="如：高等数学"
            placeholderClass={styles.placeholder}
            maxlength={20}
            value={name}
            onInput={e => setName(e.detail.value)}
          />
        </View>
        <View className={styles.field}>
          <Text className={styles.fieldLabel}>授课教师</Text>
          <Input
            className={styles.fieldInput}
            placeholder="如：王老师"
            placeholderClass={styles.placeholder}
            maxlength={20}
            value={teacher}
            onInput={e => setTeacher(e.detail.value)}
          />
        </View>
        <View className={styles.field}>
          <Text className={styles.fieldLabel}>上课地点</Text>
          <Input
            className={styles.fieldInput}
            placeholder="如：教一楼 301"
            placeholderClass={styles.placeholder}
            maxlength={30}
            value={location}
            onInput={e => setLocation(e.detail.value)}
          />
        </View>
        <View className={styles.field}>
          <Text className={styles.fieldLabel}>上课日</Text>
          <View className={styles.weekdayGrid}>
            {WEEKDAYS.map(w => (
              <View
                key={w.value}
                className={classnames(styles.weekdayChip, {
                  [styles.weekdayChipActive]: weekdays.includes(w.value)
                })}
                onClick={() => toggleWeekday(w.value)}
              >
                <Text
                  className={classnames(styles.weekdayText, {
                    [styles.weekdayTextActive]: weekdays.includes(w.value)
                  })}
                >
                  {w.label}
                </Text>
              </View>
            ))}
          </View>
        </View>
        <View className={styles.field}>
          <Text className={styles.fieldLabel}>截止时间</Text>
          <Picker
            mode="time"
            value={deadline}
            start="00:00"
            end="23:59"
            onChange={e => setDeadline(e.detail.value)}
          >
            <Text className={styles.pickerValue}>每日 {deadline}</Text>
          </Picker>
        </View>
      </View>

      <Text className={styles.tip}>
        在每日截止时间前完成签到记为「已签到」，超时未签记为「漏签」。
      </Text>

      <Button
        className={styles.saveButton}
        loading={saving}
        disabled={saving}
        onClick={handleSave}
      >
        <Text className={styles.saveButtonText}>保存课程</Text>
      </Button>
    </View>
  );
};

export default CourseEditPage;
