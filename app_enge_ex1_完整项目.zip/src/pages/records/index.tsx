import React, { useMemo } from 'react';
import { View, Text } from '@tarojs/components';
import Taro from '@tarojs/taro';
import styles from './index.module.scss';
import { useCourseStore } from '@/store/courseStore';
import { useThemeStore } from '@/store/themeStore';
import { getAttendance } from '@/services/courseService';
import StatCard from '@/components/StatCard';
import ProgressBar from '@/components/ProgressBar';

const WEEKDAY_SHORT = ['日', '一', '二', '三', '四', '五', '六'];

function formatWeekdays(weekdays: number[]): string {
  return weekdays
    .slice()
    .sort((a, b) => a - b)
    .map(w => `周${WEEKDAY_SHORT[w]}`)
    .join(' · ');
}

const RecordsPage: React.FC = () => {
  const { courses, records } = useCourseStore();
  const { themeStyle } = useThemeStore();

  // 每门课的签到率
  const items = useMemo(() => {
    return courses.map(course => ({
      course,
      attendance: getAttendance(course, records)
    }));
  }, [courses, records]);

  // 全局平均签到率
  const overall = useMemo(() => {
    const totalRequired = items.reduce((sum, i) => sum + i.attendance.required, 0);
    const totalAttended = items.reduce((sum, i) => sum + i.attendance.attended, 0);
    return {
      rate: totalRequired === 0 ? 0 : Math.round((totalAttended / totalRequired) * 100),
      required: totalRequired,
      attended: totalAttended
    };
  }, [items]);

  const goDetail = (courseId: string) => {
    Taro.navigateTo({ url: `/pages/courseDetail/index?id=${courseId}` });
  };

  return (
    <View className={styles.page} style={themeStyle}>
      <View className={styles.statsRow}>
        <StatCard value={overall.rate} unit="%" label="平均签到率" highlight />
        <StatCard value={courses.length} unit="门" label="我的课程" />
        <StatCard value={overall.attended} unit="次" label="累计已到" />
      </View>

      {courses.length === 0 ? (
        <View className={styles.empty}>
          <Text className={styles.emptyIcon}>🗂️</Text>
          <Text className={styles.emptyText}>还没有课程，去「我的」添加课程吧</Text>
        </View>
      ) : (
        <View className={styles.list}>
          {items.map(({ course, attendance }) => (
            <View
              key={course.id}
              className={styles.courseCard}
              onClick={() => goDetail(course.id)}
            >
              <View className={styles.cardTop}>
                <Text className={styles.courseName}>{course.name}</Text>
                <View>
                  <Text className={styles.rateValue}>{attendance.rate}</Text>
                  <Text className={styles.rateSymbol}>%</Text>
                </View>
              </View>
              <Text className={styles.courseMeta}>
                {course.teacher} · {course.location} · {formatWeekdays(course.weekdays)}
              </Text>
              <View className={styles.progressRow}>
                <View className={styles.progress}>
                  <ProgressBar percent={attendance.rate} />
                </View>
                <View className={styles.countInfo}>
                  <Text className={styles.attendedText}>已到 {attendance.attended}</Text>
                  <Text className={styles.missedText}>漏签 {attendance.missed}</Text>
                </View>
              </View>
            </View>
          ))}
        </View>
      )}
    </View>
  );
};

export default RecordsPage;
