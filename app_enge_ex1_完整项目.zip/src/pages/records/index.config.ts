export default definePageConfig({
  navigationBarTitleText: '签到记录',
  enablePullDownRefresh: false,
  backgroundTextStyle: 'light'
});
