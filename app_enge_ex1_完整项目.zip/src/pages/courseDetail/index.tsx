import React, { useMemo } from 'react';
import { View, Text } from '@tarojs/components';
import { useRouter } from '@tarojs/taro';
import dayjs from 'dayjs';
import classnames from 'classnames';
import styles from './index.module.scss';
import { useCourseStore } from '@/store/courseStore';
import { useThemeStore } from '@/store/themeStore';
import {
  getAttendance,
  getRequiredDates,
  getSessionStatus
} from '@/services/courseService';
import type { SessionStatus } from '@/types/course';
import Calendar from '@/components/Calendar';
import ProgressBar from '@/components/ProgressBar';
import BackButton from '@/components/BackButton';

const WEEKDAY_SHORT = ['日', '一', '二', '三', '四', '五', '六'];

function formatWeekdays(weekdays: number[]): string {
  return weekdays
    .slice()
    .sort((a, b) => a - b)
    .map(w => `周${WEEKDAY_SHORT[w]}`)
    .join(' · ');
}

const CourseDetailPage: React.FC = () => {
  const router = useRouter();
  const courseId = router.params.id || '';
  const { courses, records } = useCourseStore();
  const { themeStyle } = useThemeStore();

  const course = courses.find(c => c.id === courseId);

  // 本月日历状态
  const monthStr = dayjs().format('YYYY-MM');
  const statusMap = useMemo(() => {
    if (!course) return {};
    const map: Record<string, SessionStatus> = {};
    const start = dayjs(monthStr + '-01');
    const days = start.daysInMonth();
    for (let d = 1; d <= days; d++) {
      const date = start.date(d);
      const status = getSessionStatus(course, records, date);
      if (status !== 'none') {
        map[date.format('YYYY-MM-DD')] = status;
      }
    }
    return map;
  }, [course, records, monthStr]);

  // 签到率
  const attendance = useMemo(() => {
    if (!course) return null;
    return getAttendance(course, records);
  }, [course, records]);

  // 历史课次（倒序，最近 30 条）
  const history = useMemo(() => {
    if (!course) return [];
    const recordMap = new Map(
      records.filter(r => r.courseId === course.id).map(r => [r.date, r])
    );
    return getRequiredDates(course)
      .slice(-30)
      .reverse()
      .map(dateStr => {
        const record = recordMap.get(dateStr);
        return {
          date: dateStr,
          checked: !!record,
          time: record ? dayjs(record.timestamp).format('HH:mm') : ''
        };
      });
  }, [course, records]);

  if (!course || !attendance) {
    return (
      <View className={styles.page} style={themeStyle}>
        <BackButton />
        <View className={styles.notFound}>
          <Text className={styles.notFoundText}>课程不存在或已被删除</Text>
        </View>
      </View>
    );
  }

  return (
    <View className={styles.page} style={themeStyle}>
      <BackButton />
      <View className={styles.hero}>
        <Text className={styles.courseName}>{course.name}</Text>
        <Text className={styles.heroMeta}>授课教师：{course.teacher}</Text>
        <Text className={styles.heroMeta}>上课地点：{course.location}</Text>
        <Text className={styles.heroMeta}>上课时间：{formatWeekdays(course.weekdays)}</Text>
        <Text className={styles.heroMeta}>签到截止：每日 {course.deadline}</Text>
      </View>

      <View className={styles.rateCard}>
        <View className={styles.rateTop}>
          <Text className={styles.rateLabel}>签到率</Text>
          <Text className={styles.rateValue}>{attendance.rate}</Text>
          <Text className={styles.rateSymbol}>%</Text>
        </View>
        <ProgressBar percent={attendance.rate} height={20} />
        <View className={styles.rateCounts}>
          <Text className={styles.countRequired}>应到 {attendance.required} 次</Text>
          <Text className={styles.countAttended}>已到 {attendance.attended} 次</Text>
          <Text className={styles.countMissed}>漏签 {attendance.missed} 次</Text>
        </View>
      </View>

      <View className={styles.section}>
        <Calendar month={monthStr} statusMap={statusMap} />
      </View>

      <View className={styles.section}>
        <Text className={styles.sectionTitle}>近期课次</Text>
        {history.length === 0 ? (
          <View className={styles.emptyHistory}>
            <Text>暂无已结束的课次记录</Text>
          </View>
        ) : (
          <View className={styles.historyList}>
            {history.map(item => {
              const d = dayjs(item.date);
              return (
                <View key={item.date} className={styles.historyItem}>
                  <View className={styles.historyDate}>
                    <Text className={styles.historyDay}>{d.format('M月D日')}</Text>
                    <Text className={styles.historyWeek}>周{WEEKDAY_SHORT[d.day()]}</Text>
                  </View>
                  <Text className={styles.historyInfo}>
                    {item.checked ? `签到时间 ${item.time}` : '超过截止时间未签到'}
                  </Text>
                  <Text
                    className={classnames(
                      styles.badge,
                      item.checked ? styles.badgeChecked : styles.badgeMissed
                    )}
                  >
                    {item.checked ? '已签到' : '漏签'}
                  </Text>
                </View>
              );
            })}
          </View>
        )}
      </View>
    </View>
  );
};

export default CourseDetailPage;
