import React, { useMemo } from 'react';
import { View, Text, Button } from '@tarojs/components';
import Taro from '@tarojs/taro';
import classnames from 'classnames';
import styles from './index.module.scss';
import { useCourseStore } from '@/store/courseStore';
import { useThemeStore } from '@/store/themeStore';
import { getAttendance } from '@/services/courseService';

const WEEKDAY_SHORT = ['日', '一', '二', '三', '四', '五', '六'];

function formatWeekdays(weekdays: number[]): string {
  return weekdays
    .slice()
    .sort((a, b) => a - b)
    .map(w => `周${WEEKDAY_SHORT[w]}`)
    .join(' · ');
}

const MinePage: React.FC = () => {
  const { courses, records, removeCourse, resetToMock } = useCourseStore();
  const { theme, themes, themeStyle, setThemeId } = useThemeStore();

  // 平均签到率
  const overallRate = useMemo(() => {
    let required = 0;
    let attended = 0;
    courses.forEach(c => {
      const a = getAttendance(c, records);
      required += a.required;
      attended += a.attended;
    });
    return required === 0 ? 0 : Math.round((attended / required) * 100);
  }, [courses, records]);

  const handleAdd = () => {
    Taro.navigateTo({ url: '/pages/courseEdit/index' });
  };

  const handleDelete = (courseId: string, name: string) => {
    Taro.showModal({
      title: '删除课程',
      content: `确定删除「${name}」吗？该课程的签到记录将一并删除。`,
      confirmText: '删除',
      confirmColor: '#f53f3f',
      success: res => {
        if (res.confirm) {
          removeCourse(courseId);
          Taro.showToast({ title: '已删除', icon: 'success' });
        }
      }
    });
  };

  const handleReset = () => {
    Taro.showModal({
      title: '重置演示数据',
      content: '将清空全部课程与签到记录，并恢复为初始演示课程，确定继续？',
      confirmText: '重置',
      confirmColor: '#f53f3f',
      success: res => {
        if (res.confirm) {
          resetToMock();
          Taro.showToast({ title: '已重置', icon: 'success' });
        }
      }
    });
  };

  return (
    <View className={styles.page} style={themeStyle}>
      <View className={styles.profile}>
        <View className={styles.avatar}>
          <Text>🎓</Text>
        </View>
        <View className={styles.profileInfo}>
          <Text className={styles.nickname}>课程签到</Text>
          <Text className={styles.subLabel}>
            {courses.length} 门课程 · 平均签到率 {overallRate}%
          </Text>
        </View>
      </View>

      {/* 主题色选择 */}
      <View className={styles.section}>
        <Text className={styles.sectionTitle}>主题颜色</Text>
        <View className={styles.themeGrid}>
          {themes.map(t => (
            <View key={t.id} className={styles.themeItem} onClick={() => setThemeId(t.id)}>
              <View
                className={classnames(styles.themeDot, {
                  [styles.themeDotActive]: t.id === theme.id
                })}
                style={{ backgroundColor: t.primary }}
              >
                {t.id === theme.id ? <Text className={styles.themeCheck}>✓</Text> : null}
              </View>
              <Text
                className={classnames(styles.themeName, {
                  [styles.themeNameActive]: t.id === theme.id
                })}
              >
                {t.name}
              </Text>
            </View>
          ))}
        </View>
      </View>

      {/* 课程管理 */}
      <View className={styles.section}>
        <Text className={styles.sectionTitle}>我的课程（{courses.length}）</Text>
        {courses.length === 0 ? (
          <View className={styles.emptyCourses}>
            <Text>还没有添加课程</Text>
          </View>
        ) : (
          <View className={styles.courseList}>
            {courses.map(course => (
              <View key={course.id} className={styles.courseRow}>
                <View className={styles.courseRowInfo}>
                  <Text className={styles.courseRowName}>{course.name}</Text>
                  <Text className={styles.courseRowMeta}>
                    {course.teacher} · {formatWeekdays(course.weekdays)} · 截止 {course.deadline}
                  </Text>
                </View>
                <Button
                  className={styles.deleteBtn}
                  onClick={() => handleDelete(course.id, course.name)}
                >
                  <Text className={styles.deleteText}>删除</Text>
                </Button>
              </View>
            ))}
          </View>
        )}
        <Button className={styles.addButton} onClick={handleAdd}>
          <Text className={styles.addButtonText}>＋ 添加课程</Text>
        </Button>
      </View>

      <Button className={styles.resetButton} onClick={handleReset}>
        <Text className={styles.resetText}>重置为演示数据</Text>
      </Button>
    </View>
  );
};

export default MinePage;
