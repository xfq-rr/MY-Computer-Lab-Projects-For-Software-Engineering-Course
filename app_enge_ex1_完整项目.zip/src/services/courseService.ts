import Taro from '@tarojs/taro';
import dayjs from 'dayjs';
import type {
  Course,
  CheckinRecord,
  SessionStatus,
  CourseAttendance
} from '@/types/course';

const STORAGE_COURSES = 'course_list_v1';
const STORAGE_RECORDS = 'checkin_records_v2';
const STORAGE_INIT_FLAG = 'course_mock_init_v1';

// ============================================
// 时间 / 状态工具
// ============================================

/** 判断指定日期是否为该课程的上课日 */
export function isClassDay(course: Course, date: dayjs.Dayjs): boolean {
  return course.weekdays.includes(date.day());
}

/** 将课程的 HH:mm 截止时间转换为指定日期的时间点。 */
function getDeadlineMoment(course: Course, date: dayjs.Dayjs): dayjs.Dayjs {
  const [rawHour, rawMinute] = course.deadline.split(':').map(Number);
  const hour = Number.isInteger(rawHour) && rawHour >= 0 && rawHour <= 23
    ? rawHour
    : 23;
  const minute = Number.isInteger(rawMinute) && rawMinute >= 0 && rawMinute <= 59
    ? rawMinute
    : 59;

  return dayjs(date)
    .hour(hour)
    .minute(minute)
    .second(59)
    .millisecond(999);
}

/**
 * 判断课程在指定日期的课次状态
 * @param course 课程
 * @param date 日期（默认今天）
 * @param records 签到记录
 * @param now 当前时间（默认本机时间，测试可注入）
 */
export function getSessionStatus(
  course: Course,
  records: CheckinRecord[],
  date: dayjs.Dayjs = dayjs(),
  now: dayjs.Dayjs = dayjs()
): SessionStatus {
  const targetDate = date.startOf('day');
  const createdDate = dayjs(course.createdAt).startOf('day');
  const today = now.startOf('day');

  // 课程创建前和尚未到来的日期都不属于可签到课次。
  if (targetDate.isBefore(createdDate, 'day') || targetDate.isAfter(today, 'day')) {
    return 'none';
  }
  if (!isClassDay(course, targetDate)) return 'none';

  const dateStr = targetDate.format('YYYY-MM-DD');
  const signed = records.some(r => r.courseId === course.id && r.date === dateStr);
  if (signed) return 'checked';

  // 今日：比较当前时间与截止时间；过去日期一律视为漏签
  const deadlineMoment = getDeadlineMoment(course, targetDate);
  if (now.isAfter(deadlineMoment)) return 'missed';

  return 'pending';
}

/**
 * 枚举课程从创建日到指定截止日之间所有「应到」日期（上课日且截止时间已过）
 */
export function getRequiredDates(
  course: Course,
  until: dayjs.Dayjs = dayjs(),
  now: dayjs.Dayjs = dayjs()
): string[] {
  const dates: string[] = [];
  const start = dayjs(course.createdAt).startOf('day');
  const end = until.startOf('day');

  for (let d = start; !d.isAfter(end, 'day'); d = d.add(1, 'day')) {
    if (!isClassDay(course, d)) continue;
    const deadlineMoment = getDeadlineMoment(course, d);
    // 截止时间已过（历史日期，或今天但已过点）
    if (now.isAfter(deadlineMoment)) {
      dates.push(d.format('YYYY-MM-DD'));
    }
  }
  return dates;
}

/** 计算课程签到率 */
export function getAttendance(
  course: Course,
  records: CheckinRecord[]
): CourseAttendance {
  const requiredDates = getRequiredDates(course);
  const signedSet = new Set(
    records.filter(r => r.courseId === course.id).map(r => r.date)
  );
  let attended = 0;
  requiredDates.forEach(d => {
    if (signedSet.has(d)) attended += 1;
  });
  const required = requiredDates.length;
  const missed = required - attended;
  const rate = required === 0 ? 0 : Math.round((attended / required) * 100);
  return { required, attended, missed, rate };
}

// ============================================
// 存储读写
// ============================================

export function getCourses(): Course[] {
  try {
    const raw = Taro.getStorageSync(STORAGE_COURSES);
    return Array.isArray(raw) ? (raw as Course[]) : [];
  } catch (err) {
    console.error('[Course] 读取课程失败', err);
    return [];
  }
}

export function getRecords(): CheckinRecord[] {
  try {
    const raw = Taro.getStorageSync(STORAGE_RECORDS);
    return Array.isArray(raw) ? (raw as CheckinRecord[]) : [];
  } catch (err) {
    console.error('[Course] 读取签到记录失败', err);
    return [];
  }
}

function saveCourses(courses: Course[]): void {
  Taro.setStorageSync(STORAGE_COURSES, courses);
}

function saveRecords(records: CheckinRecord[]): void {
  Taro.setStorageSync(STORAGE_RECORDS, records);
}

// ============================================
// 业务操作
// ============================================

/** 课程签到（仅当今日处于 pending 状态时成功） */
export function checkinCourse(
  courseId: string
): { success: boolean; message: string; record?: CheckinRecord } {
  const courses = getCourses();
  const course = courses.find(c => c.id === courseId);
  if (!course) {
    return { success: false, message: '课程不存在' };
  }
  const records = getRecords();
  const status = getSessionStatus(course, records);

  if (status === 'checked') {
    return { success: false, message: '该课程今日已签到' };
  }
  if (status === 'missed') {
    return { success: false, message: '已超过今日签到截止时间' };
  }
  if (status === 'none') {
    return { success: false, message: '今天不是该课程的上课日' };
  }

  const newRecord: CheckinRecord = {
    courseId,
    date: dayjs().format('YYYY-MM-DD'),
    timestamp: Date.now()
  };
  saveRecords([...records, newRecord]);
  console.info('[Course] 签到成功', newRecord);
  return { success: true, message: '签到成功', record: newRecord };
}

/** 新增课程 */
export function addCourse(
  input: Omit<Course, 'id' | 'createdAt'>
): Course {
  const course: Course = {
    ...input,
    id: `c_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    createdAt: Date.now()
  };
  const courses = getCourses();
  saveCourses([...courses, course]);
  console.info('[Course] 新增课程', course);
  return course;
}

/** 删除课程（级联删除其签到记录） */
export function removeCourse(courseId: string): void {
  const courses = getCourses().filter(c => c.id !== courseId);
  const records = getRecords().filter(r => r.courseId !== courseId);
  saveCourses(courses);
  saveRecords(records);
  console.info('[Course] 删除课程', courseId);
}

/** 清空全部课程数据（回到初始 mock） */
export function resetAllData(): void {
  Taro.removeStorageSync(STORAGE_COURSES);
  Taro.removeStorageSync(STORAGE_RECORDS);
  Taro.removeStorageSync(STORAGE_INIT_FLAG);
  console.info('[Course] 已清空课程数据');
}

// ============================================
// 初始 Mock 数据（首次启动写入）
// ============================================

/** 确定性判定历史某天是否漏签（按课程漏签概率，保证签到率稳定可演示） */
function isMockMissed(courseId: string, dayOffset: number, missMod: number): boolean {
  // missMod 越大漏签越多；hash 为 0..9
  const idSeed = courseId.split('').reduce((s, ch) => s + ch.charCodeAt(0), 0);
  const hash = (dayOffset * 7 + idSeed) % 10;
  return hash < missMod;
}

export function ensureMockData(): { courses: Course[]; records: CheckinRecord[] } {
  let courses = getCourses();
  let records = getRecords();
  const initialized = Taro.getStorageSync(STORAGE_INIT_FLAG);

  // 初始化标记存在时尊重当前存储状态，包括用户主动删除全部课程的情况。
  if (initialized) {
    return { courses, records };
  }

  // 3 门演示课程，开课时间设为 20 天前
  const createdTs = dayjs().subtract(20, 'day').valueOf();
  const todayWeekday = dayjs().day();

  const mockCourses: Array<Omit<Course, 'id' | 'createdAt'> & { id: string; missMod: number }> = [
    {
      id: 'c_mock_math',
      name: '高等数学',
      teacher: '王建国 教授',
      location: '教一楼 301',
      // 一、三、五，并保证今日有课
      weekdays: Array.from(new Set([1, 3, 5, todayWeekday])),
      deadline: '23:59',
      missMod: 1 // 约 10% 漏签
    },
    {
      id: 'c_mock_english',
      name: '大学英语',
      teacher: '李雅琴 老师',
      location: '教二楼 205',
      weekdays: Array.from(new Set([2, 4, todayWeekday])),
      deadline: '23:59',
      missMod: 2 // 约 20% 漏签
    },
    {
      id: 'c_mock_coding',
      name: '程序设计基础',
      teacher: '张一鸣 老师',
      location: '实验楼 A-401',
      weekdays: Array.from(new Set([1, 4, todayWeekday])),
      deadline: '23:59',
      missMod: 0 // 全勤
    }
  ];

  courses = mockCourses.map(({ missMod, ...rest }) => ({ ...rest, createdAt: createdTs }));

  // 生成历史签到记录（今日留空，供用户现场签到）
  records = [];
  const today = dayjs();
  courses.forEach(course => {
    const target = mockCourses.find(m => m.id === course.id)!;
    for (let offset = 20; offset >= 1; offset--) {
      const d = today.subtract(offset, 'day');
      if (!isClassDay(course, d)) continue;
      if (isMockMissed(course.id, offset, target.missMod)) continue;
      records.push({
        courseId: course.id,
        date: d.format('YYYY-MM-DD'),
        timestamp: d.hour(9).minute(15).valueOf()
      });
    }
  });

  saveCourses(courses);
  saveRecords(records);
  Taro.setStorageSync(STORAGE_INIT_FLAG, 1);
  console.info('[Course] 初始 Mock 数据写入完成', { courses: courses.length, records: records.length });

  return { courses, records };
}
