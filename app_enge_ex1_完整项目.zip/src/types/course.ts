// 课程签到相关类型定义

/** 课程 */
export interface Course {
  /** 课程 ID */
  id: string;
  /** 课程名称 */
  name: string;
  /** 授课教师 */
  teacher: string;
  /** 上课地点 */
  location: string;
  /** 每周上课日，0=周日 1=周一 ... 6=周六 */
  weekdays: number[];
  /** 每日签到截止时间 HH:mm（过了该时间未签到记为漏签） */
  deadline: string;
  /** 课程创建时间戳（作为应到课次的统计起点） */
  createdAt: number;
}

/** 一次签到记录 */
export interface CheckinRecord {
  /** 课程 ID */
  courseId: string;
  /** 签到日期 YYYY-MM-DD */
  date: string;
  /** 签到时间戳 */
  timestamp: number;
}

/** 单次课的状态 */
export type SessionStatus =
  | 'checked' // 已签到
  | 'pending' // 待签到（今日有课且未过截止时间）
  | 'missed' // 漏签（应到但过了截止时间）
  | 'none'; // 当日无课

/** 课程 + 今日状态组合（首页列表用） */
export interface CourseTodayItem {
  course: Course;
  status: SessionStatus;
}

/** 课程签到率统计 */
export interface CourseAttendance {
  /** 应到课次 */
  required: number;
  /** 已到课次 */
  attended: number;
  /** 漏签课次 */
  missed: number;
  /** 签到率 0-100（整数） */
  rate: number;
}

/** 日历单格状态（课程详情用） */
export interface CalendarCell {
  /** 日期 YYYY-MM-DD */
  date: string;
  /** 是否本月 */
  inMonth: boolean;
  /** 是否今天 */
  isToday: boolean;
  /** 当日课次状态 */
  status: SessionStatus;
}

/** 主题预设 */
export interface ThemeOption {
  /** 主题 ID */
  id: string;
  /** 主题名称 */
  name: string;
  /** 主色 */
  primary: string;
  /** 主色浅（渐变用） */
  primaryLight: string;
  /** 主色深 */
  primaryDark: string;
  /** RGB 三元组 "r,g,b"（用于 rgba 阴影/透明底色） */
  rgb: string;
}
