import React, {
  createContext,
  useContext,
  useEffect,
  useReducer,
  useCallback,
  useMemo,
  useState
} from 'react';
import { useDidShow } from '@tarojs/taro';
import dayjs from 'dayjs';
import type { Course, CheckinRecord, CourseTodayItem } from '@/types/course';
import {
  ensureMockData,
  checkinCourse,
  addCourse as addCourseSvc,
  removeCourse as removeCourseSvc,
  getSessionStatus,
  resetAllData
} from '@/services/courseService';

interface CourseState {
  courses: Course[];
  records: CheckinRecord[];
  loading: boolean;
}

const initialState: CourseState = {
  courses: [],
  records: [],
  loading: true
};

type Action =
  | { type: 'init'; payload: { courses: Course[]; records: CheckinRecord[] } }
  | { type: 'checkin'; payload: CheckinRecord }
  | { type: 'add'; payload: Course }
  | { type: 'remove'; payload: { courseId: string } }
  | { type: 'reset'; payload: { courses: Course[]; records: CheckinRecord[] } };

function reducer(state: CourseState, action: Action): CourseState {
  switch (action.type) {
    case 'init':
      return { ...action.payload, loading: false };
    case 'checkin':
      return { ...state, records: [...state.records, action.payload] };
    case 'add':
      return { ...state, courses: [...state.courses, action.payload] };
    case 'remove':
      return {
        loading: state.loading,
        courses: state.courses.filter(c => c.id !== action.payload.courseId),
        records: state.records.filter(r => r.courseId !== action.payload.courseId)
      };
    case 'reset':
      return { ...action.payload, loading: false };
    default:
      return state;
  }
}

interface CourseContextValue extends CourseState {
  /** 今日课程列表（含状态），仅返回今天有课的课程 */
  todayList: CourseTodayItem[];
  /** 今日待签到数量 */
  pendingCount: number;
  /** 给某课程签到 */
  performCheckin: (courseId: string) => { success: boolean; message: string };
  /** 添加课程 */
  addCourse: (input: Omit<Course, 'id' | 'createdAt'>) => Course;
  /** 删除课程 */
  removeCourse: (courseId: string) => void;
  /** 重置为初始 mock 数据 */
  resetToMock: () => void;
}

const CourseContext = createContext<CourseContextValue | null>(null);

export const CourseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState);
  const [nowTimestamp, setNowTimestamp] = useState(Date.now);

  const refreshClock = useCallback(() => {
    setNowTimestamp(Date.now());
  }, []);

  // 应用/页面重新显示时立即刷新，避免从后台回来后仍展示旧日期或旧状态。
  useDidShow(refreshClock);

  useEffect(() => {
    const { courses, records } = ensureMockData();
    dispatch({ type: 'init', payload: { courses, records } });
    console.info('[CourseStore] 初始化完成', { courses: courses.length, records: records.length });
  }, []);

  // 常驻页面每分钟重算一次，覆盖截止时间跨越和午夜切换场景。
  useEffect(() => {
    const timer = setInterval(refreshClock, 60 * 1000);
    return () => clearInterval(timer);
  }, [refreshClock]);

  const performCheckin = useCallback((courseId: string) => {
    const result = checkinCourse(courseId);
    if (result.success && result.record) {
      dispatch({ type: 'checkin', payload: result.record });
    }
    return { success: result.success, message: result.message };
  }, []);

  const addCourse = useCallback((input: Omit<Course, 'id' | 'createdAt'>) => {
    const course = addCourseSvc(input);
    dispatch({ type: 'add', payload: course });
    return course;
  }, []);

  const removeCourse = useCallback((courseId: string) => {
    removeCourseSvc(courseId);
    dispatch({ type: 'remove', payload: { courseId } });
  }, []);

  const resetToMock = useCallback(() => {
    resetAllData();
    const { courses, records } = ensureMockData();
    dispatch({ type: 'reset', payload: { courses, records } });
  }, []);

  const todayList = useMemo<CourseTodayItem[]>(() => {
    const now = dayjs(nowTimestamp);
    return state.courses
      .filter(c => c.weekdays.includes(now.day()))
      .map(course => ({
        course,
        status: getSessionStatus(course, state.records, now, now)
      }));
  }, [state.courses, state.records, nowTimestamp]);

  const pendingCount = useMemo(
    () => todayList.filter(item => item.status === 'pending').length,
    [todayList]
  );

  return (
    <CourseContext.Provider
      value={{
        ...state,
        todayList,
        pendingCount,
        performCheckin,
        addCourse,
        removeCourse,
        resetToMock
      }}
    >
      {children}
    </CourseContext.Provider>
  );
};

export function useCourseStore(): CourseContextValue {
  const ctx = useContext(CourseContext);
  if (!ctx) {
    throw new Error('useCourseStore 必须在 CourseProvider 内使用');
  }
  return ctx;
}
