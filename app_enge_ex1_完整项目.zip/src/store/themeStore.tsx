import React, {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  useCallback
} from 'react';
import Taro, { useDidShow } from '@tarojs/taro';
import type { ThemeOption } from '@/types/course';

const STORAGE_THEME = 'theme_id_v1';

/** 6 套预设主题 */
export const THEMES: ThemeOption[] = [
  {
    id: 'orange',
    name: '活力橙',
    primary: '#ff6b35',
    primaryLight: '#ff8e53',
    primaryDark: '#e85a25',
    rgb: '255,107,53'
  },
  {
    id: 'blue',
    name: '天空蓝',
    primary: '#165dff',
    primaryLight: '#4080ff',
    primaryDark: '#0e42d2',
    rgb: '22,93,255'
  },
  {
    id: 'green',
    name: '森林绿',
    primary: '#00b42a',
    primaryLight: '#36c75a',
    primaryDark: '#009a22',
    rgb: '0,180,42'
  },
  {
    id: 'purple',
    name: '葡萄紫',
    primary: '#7c3aed',
    primaryLight: '#9a63f2',
    primaryDark: '#6429c4',
    rgb: '124,58,237'
  },
  {
    id: 'red',
    name: '玫瑰红',
    primary: '#f53f3f',
    primaryLight: '#f76560',
    primaryDark: '#d92b2b',
    rgb: '245,63,63'
  },
  {
    id: 'teal',
    name: '青松青',
    primary: '#0fb5c4',
    primaryLight: '#3bc9d6',
    primaryDark: '#0a95a3',
    rgb: '15,181,196'
  }
];

const DEFAULT_THEME = THEMES[0];

const TAB_ITEMS = [
  { name: 'home', text: '签到' },
  { name: 'records', text: '记录' },
  { name: 'mine', text: '我的' }
];

interface ThemeContextValue {
  /** 当前主题 */
  theme: ThemeOption;
  /** 全部主题 */
  themes: ThemeOption[];
  /** 切换主题 */
  setThemeId: (id: string) => void;
  /** 注入到页面根节点的 CSS 变量 style */
  themeStyle: React.CSSProperties;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

function readStoredThemeId(): string {
  try {
    return Taro.getStorageSync(STORAGE_THEME) || DEFAULT_THEME.id;
  } catch {
    return DEFAULT_THEME.id;
  }
}

/** 将当前主题同步到原生导航栏和 tabBar。 */
function syncSystemTheme(theme: ThemeOption): void {
  const noop = () => {};

  try {
    Taro.setNavigationBarColor({
      frontColor: '#ffffff',
      backgroundColor: theme.primary,
      fail: noop
    });
  } catch {
    /* 平台不支持时忽略 */
  }

  try {
    Taro.setTabBarStyle({
      selectedColor: theme.primary,
      fail: noop
    });
  } catch {
    /* 平台不支持时忽略 */
  }

  // 每个主题都有一套选中态 PNG 图标。
  TAB_ITEMS.forEach((item, index) => {
    try {
      Taro.setTabBarItem({
        index,
        text: item.text,
        iconPath: `assets/tabbar/${item.name}.png`,
        selectedIconPath: `assets/tabbar/${item.name}-selected-${theme.id}.png`,
        fail: noop
      });
    } catch {
      /* 平台不支持时忽略 */
    }
  });
}

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [themeId, setThemeIdState] = useState<string>(readStoredThemeId);

  const theme = useMemo(() => {
    return THEMES.find(t => t.id === themeId) || DEFAULT_THEME;
  }, [themeId]);

  // 主题变化时持久化，并立即同步当前页面的系统 UI。
  useEffect(() => {
    try {
      Taro.setStorageSync(STORAGE_THEME, theme.id);
    } catch (err) {
      console.error('[Theme] 主题持久化失败', err);
    }

    syncSystemTheme(theme);
  }, [theme]);

  // 页面跳转或应用从后台恢复时，页面配置可能重置导航栏，因此再次同步。
  useDidShow(() => {
    syncSystemTheme(theme);
  });

  const setThemeId = useCallback((id: string) => {
    if (THEMES.some(t => t.id === id)) {
      setThemeIdState(id);
    }
  }, []);

  // 注入到页面根容器的 CSS 变量
  const themeStyle = useMemo<React.CSSProperties>(
    () =>
      ({
        '--theme-primary': theme.primary,
        '--theme-primary-light': theme.primaryLight,
        '--theme-primary-dark': theme.primaryDark,
        '--theme-rgb': theme.rgb
      }) as React.CSSProperties,
    [theme]
  );

  return (
    <ThemeContext.Provider value={{ theme, themes: THEMES, setThemeId, themeStyle }}>
      {children}
    </ThemeContext.Provider>
  );
};

export function useThemeStore(): ThemeContextValue {
  const ctx = useContext(ThemeContext);
  if (!ctx) {
    throw new Error('useThemeStore 必须在 ThemeProvider 内使用');
  }
  return ctx;
}
