import React from 'react';
import { View, Text } from '@tarojs/components';
import classnames from 'classnames';
import styles from './index.module.scss';

interface StatCardProps {
  /** 数值 */
  value: number | string;
  /** 标签 */
  label: string;
  /** 单位（如：%、门） */
  unit?: string;
  /** 是否强调主色（主题渐变底） */
  highlight?: boolean;
  /** 自定义类名 */
  className?: string;
}

const StatCard: React.FC<StatCardProps> = ({ value, label, unit, highlight, className }) => {
  return (
    <View
      className={classnames(styles.card, { [styles.highlight]: highlight }, className)}
    >
      <View className={styles.valueRow}>
        <Text className={styles.value}>{value}</Text>
        {unit ? <Text className={styles.unit}>{unit}</Text> : null}
      </View>
      <Text className={styles.label}>{label}</Text>
    </View>
  );
};

export default StatCard;
