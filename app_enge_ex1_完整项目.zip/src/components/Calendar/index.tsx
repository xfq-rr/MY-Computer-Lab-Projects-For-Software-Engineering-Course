import React, { useMemo } from 'react';
import { View, Text } from '@tarojs/components';
import dayjs from 'dayjs';
import classnames from 'classnames';
import type { CalendarCell, SessionStatus } from '@/types/course';
import styles from './index.module.scss';

interface CalendarProps {
  /** 显示的月份 YYYY-MM，默认本月 */
  month?: string;
  /** 日期 -> 课次状态（checked / missed / pending），由页面计算 */
  statusMap?: Record<string, SessionStatus>;
}

const WEEKS = ['日', '一', '二', '三', '四', '五', '六'];

/** 构造日历所有格子（含上月末和下月头的占位） */
function buildCells(month: string, statusMap: Record<string, SessionStatus>): CalendarCell[] {
  const start = dayjs(month + '-01');
  const daysInMonth = start.daysInMonth();
  const today = dayjs().format('YYYY-MM-DD');

  const cells: CalendarCell[] = [];
  const firstWeekday = start.day();
  for (let i = 0; i < firstWeekday; i++) {
    cells.push({
      date: start.subtract(firstWeekday - i, 'day').format('YYYY-MM-DD'),
      inMonth: false,
      isToday: false,
      status: 'none'
    });
  }
  for (let d = 1; d <= daysInMonth; d++) {
    const dateStr = start.date(d).format('YYYY-MM-DD');
    cells.push({
      date: dateStr,
      inMonth: true,
      isToday: dateStr === today,
      status: statusMap[dateStr] || 'none'
    });
  }
  const total = cells.length;
  const tail = (42 - total) > 0 ? 42 - total : (7 - (total % 7)) % 7;
  for (let i = 1; i <= tail; i++) {
    cells.push({
      date: start.add(daysInMonth + i - 1, 'day').format('YYYY-MM-DD'),
      inMonth: false,
      isToday: false,
      status: 'none'
    });
  }
  return cells;
}

const Calendar: React.FC<CalendarProps> = ({ month, statusMap }) => {
  const monthStr = month || dayjs().format('YYYY-MM');
  const map = statusMap || {};
  const cells = useMemo(() => buildCells(monthStr, map), [monthStr, map]);
  const title = dayjs(monthStr + '-01').format('YYYY年 M月');

  return (
    <View className={styles.calendar}>
      <View className={styles.header}>
        <Text className={styles.title}>{title}</Text>
      </View>
      <View className={styles.weekRow}>
        {WEEKS.map(w => (
          <View key={w} className={styles.weekCell}>
            <Text className={styles.weekText}>{w}</Text>
          </View>
        ))}
      </View>
      <View className={styles.grid}>
        {cells.map((cell, idx) => (
          <View
            key={idx}
            className={classnames(
              styles.cell,
              { [styles.cellOut]: !cell.inMonth },
              { [styles.cellChecked]: cell.status === 'checked' },
              { [styles.cellMissed]: cell.status === 'missed' },
              { [styles.cellPending]: cell.status === 'pending' },
              {
                [styles.cellTodayPlain]:
                  cell.isToday && cell.status === 'none' && cell.inMonth
              }
            )}
          >
            <Text className={styles.dayText}>
              {cell.inMonth ? dayjs(cell.date).date() : ''}
            </Text>
          </View>
        ))}
      </View>
      <View className={styles.legend}>
        <View className={styles.legendItem}>
          <View className={classnames(styles.legendDot, styles.legendChecked)} />
          <Text className={styles.legendText}>已签到</Text>
        </View>
        <View className={styles.legendItem}>
          <View className={classnames(styles.legendDot, styles.legendMissed)} />
          <Text className={styles.legendText}>漏签</Text>
        </View>
        <View className={styles.legendItem}>
          <View className={classnames(styles.legendDot, styles.legendPending)} />
          <Text className={styles.legendText}>待签到</Text>
        </View>
      </View>
    </View>
  );
};

export default Calendar;
