import React from 'react';
import { View } from '@tarojs/components';
import styles from './index.module.scss';

interface ProgressBarProps {
  /** 百分比 0-100 */
  percent: number;
  /** 轨道高度 rpx，默认 16 */
  height?: number;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ percent, height = 16 }) => {
  const clamped = Math.max(0, Math.min(100, percent));
  return (
    <View className={styles.track} style={{ height: `${height}rpx` }}>
      <View className={styles.fill} style={{ width: `${clamped}%` }} />
    </View>
  );
};

export default ProgressBar;
