import React from 'react';
import { View, Text } from '@tarojs/components';
import Taro from '@tarojs/taro';
import styles from './index.module.scss';

interface BackButtonProps {
  /** navigateBack 失败时的兜底 tab 页 */
  fallbackUrl?: string;
}

/**
 * 二级页返回按钮
 * 仅 H5 环境显示：微信/抖音/支付宝真机使用原生导航栏返回键，无需页面内按钮
 */
const BackButton: React.FC<BackButtonProps> = ({
  fallbackUrl = '/pages/records/index'
}) => {
  // H5（WEB）端才渲染，小程序端不显示，避免与原生导航栏返回键重复
  if (Taro.getEnv() !== Taro.ENV_TYPE.WEB) {
    return null;
  }

  const handleBack = () => {
    Taro.navigateBack({
      delta: 1,
      fail: () => {
        console.warn('[BackButton] navigateBack 失败，回退到 tab 页');
        Taro.switchTab({
          url: fallbackUrl,
          fail: err => console.error('[BackButton] switchTab 失败', err)
        });
      }
    });
  };

  return (
    <View className={styles.bar}>
      <View className={styles.button} onClick={handleBack}>
        <Text className={styles.arrow}>‹</Text>
        <Text className={styles.text}>返回</Text>
      </View>
    </View>
  );
};

export default BackButton;
