import assert = require('node:assert/strict');
import Module = require('node:module');
import dayjs = require('dayjs');
import type { Course } from '../src/types/course';

type ModuleLoad = (
  request: string,
  parent: NodeModule | null,
  isMain: boolean
) => unknown;

const storage = new Map<string, unknown>();
const taroMock = {
  getStorageSync(key: string) {
    return storage.get(key);
  },
  setStorageSync(key: string, value: unknown) {
    storage.set(key, value);
  },
  removeStorageSync(key: string) {
    storage.delete(key);
  }
};

function loadCourseService(): typeof import('../src/services/courseService') {
  const moduleRuntime = Module as unknown as { _load: ModuleLoad };
  const originalLoad = moduleRuntime._load;
  moduleRuntime._load = (request, parent, isMain) => {
    if (request === '@tarojs/taro') return taroMock;
    return originalLoad.call(Module, request, parent, isMain);
  };

  try {
    return require('../src/services/courseService') as typeof import('../src/services/courseService');
  } finally {
    moduleRuntime._load = originalLoad;
  }
}

const { ensureMockData, getRequiredDates, getSessionStatus } = loadCourseService();
const targetDate = dayjs('2026-10-08T00:00:00');

function makeCourse(overrides: Partial<Course> = {}): Course {
  return {
    id: 'course_test',
    name: '测试课程',
    teacher: '测试教师',
    location: '测试教室',
    weekdays: [targetDate.day()],
    deadline: '08:00',
    createdAt: dayjs('2026-10-01T00:00:00').valueOf(),
    ...overrides
  };
}

const tests: Array<{ name: string; run: () => void }> = [
  {
    name: '08:00 截止时间不会把 0 分钟错误回退为 59 分钟',
    run: () => {
      const course = makeCourse();
      assert.equal(
        getSessionStatus(course, [], targetDate, dayjs('2026-10-08T08:00:30')),
        'pending'
      );
      assert.equal(
        getSessionStatus(course, [], targetDate, dayjs('2026-10-08T08:01:00')),
        'missed'
      );
    }
  },
  {
    name: '00:00 截止时间不会把 0 小时错误回退为 23 时',
    run: () => {
      const course = makeCourse({ deadline: '00:00' });
      assert.equal(
        getSessionStatus(course, [], targetDate, dayjs('2026-10-08T00:01:00')),
        'missed'
      );
    }
  },
  {
    name: '课程创建日前的日期不产生课次状态',
    run: () => {
      const course = makeCourse({ createdAt: targetDate.valueOf() });
      const beforeCreation = targetDate.subtract(7, 'day');
      assert.equal(
        getSessionStatus(course, [], beforeCreation, dayjs('2026-10-08T12:00:00')),
        'none'
      );
    }
  },
  {
    name: '未来日期不提前显示为待签到',
    run: () => {
      const futureDate = targetDate.add(7, 'day');
      assert.equal(
        getSessionStatus(makeCourse(), [], futureDate, dayjs('2026-10-08T12:00:00')),
        'none'
      );
    }
  },
  {
    name: '当天已有记录时状态为已签到',
    run: () => {
      const records = [{
        courseId: 'course_test',
        date: '2026-10-08',
        timestamp: dayjs('2026-10-08T07:30:00').valueOf()
      }];
      assert.equal(
        getSessionStatus(makeCourse(), records, targetDate, dayjs('2026-10-08T07:45:00')),
        'checked'
      );
    }
  },
  {
    name: '应到日期在整点截止后的下一分钟正确计入',
    run: () => {
      const course = makeCourse({ createdAt: targetDate.valueOf() });
      assert.deepEqual(
        getRequiredDates(course, targetDate, dayjs('2026-10-08T08:00:30')),
        []
      );
      assert.deepEqual(
        getRequiredDates(course, targetDate, dayjs('2026-10-08T08:01:00')),
        ['2026-10-08']
      );
    }
  },
  {
    name: '用户删空课程后不会在下次启动时重建演示数据',
    run: () => {
      storage.clear();
      storage.set('course_mock_init_v1', 1);
      storage.set('course_list_v1', []);
      storage.set('checkin_records_v2', []);

      const result = ensureMockData();
      assert.deepEqual(result, { courses: [], records: [] });
      assert.deepEqual(storage.get('course_list_v1'), []);
    }
  }
];

for (const test of tests) {
  test.run();
  console.log(`✓ ${test.name}`);
}

console.log(`\n${tests.length} 项课程服务测试全部通过。`);
