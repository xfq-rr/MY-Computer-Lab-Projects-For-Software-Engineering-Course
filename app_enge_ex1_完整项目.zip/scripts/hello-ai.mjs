const lines = [
  'Hello, AI 编程！',
  '课程签到系统工程环境已就绪。',
  '可运行 pnpm test、pnpm typecheck 和 pnpm build 完成验证。'
];

console.log(lines.join('\n'));
