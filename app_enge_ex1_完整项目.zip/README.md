# 课程签到系统

这是一个基于 Taro 4、React 18 和 TypeScript 开发的多端课程签到应用。项目以本地存储保存课程和签到记录，可运行到 H5、微信小程序和抖音小程序等目标端，适合作为移动应用工程化与 AI 辅助开发实验项目。

> 提交前提醒：请把本文“仓库地址”中的占位符替换为你实际创建的 Gitee 仓库链接，并将 `project.config.json`、`project.tt.json` 中的游客 AppID 换成发布平台分配的 AppID。

## 功能概览

- 今日签到：按课程上课日和截止时间展示待签到、已签到、漏签状态。
- 课程管理：新增、删除课程，配置教师、地点、上课日和签到截止时间。
- 签到统计：按课程统计应到、已到、漏签次数和签到率。
- 日历记录：按月查看课程签到、漏签和待签到分布。
- 主题切换：内置 6 套主题色，并同步导航栏、tabBar 和选中态图标。
- 本地持久化：课程、签到记录和主题均保存在 Taro Storage 中。
- 演示数据：首次启动自动生成 3 门课程和历史签到记录，可在“我的”页面重置。

## 技术栈

- Taro 4.1.9
- React 18
- TypeScript
- Sass / CSS Modules
- dayjs
- pnpm

## 目录结构

```text
.
├─ config/                  # Taro 构建配置
├─ scripts/                 # Hello AI 与课程服务逻辑测试
├─ src/
│  ├─ assets/tabbar/        # 多主题 tabBar 图标
│  ├─ components/           # 日历、进度条、统计卡片等组件
│  ├─ pages/                # 签到、记录、我的、课程详情、添加课程
│  ├─ services/             # 课程状态、签到、统计和本地存储逻辑
│  ├─ store/                # 课程与主题 Context
│  ├─ styles/               # 全局变量与兼容样式
│  └─ types/                # 业务类型
├─ package.json
├─ pnpm-lock.yaml
├─ project.config.json      # 微信开发者工具配置
└─ project.tt.json          # 抖音开发者工具配置
```

## 安装与运行

建议使用 Node.js 18 或更高版本及 pnpm。仓库包含锁文件，请优先进行可复现安装：

```bash
pnpm install --frozen-lockfile
```

运行 H5 开发环境：

```bash
pnpm dev:h5
```

其他常用目标端：

```bash
pnpm dev:weapp   # 微信小程序，持续构建
pnpm dev:tt      # 抖音小程序，持续构建
pnpm build       # 默认生产构建：H5
pnpm build:weapp # 微信小程序生产构建
pnpm build:tt    # 抖音小程序生产构建
```

构建结果默认输出到 `dist/`。小程序构建完成后，可分别使用微信开发者工具或抖音开发者工具导入项目根目录。

## 质量检查

```bash
pnpm hello       # 验证 Node 脚本环境并输出 Hello, AI 编程！
pnpm typecheck   # 检查项目与测试脚本的 TypeScript 类型
pnpm test        # 运行课程状态和初始化逻辑测试
pnpm build       # 验证 H5 生产构建
```

逻辑测试覆盖以下边界：

- `08:00` 截止时，`00` 分钟不会错误回退为 `59` 分钟；
- `00:00` 截止时，`0` 小时不会错误回退为 `23` 时；
- 课程创建日前和未来日期不生成课次状态；
- 已签到、截止前和截止后的状态计算；
- 用户删除全部课程后，下次启动不会自动重建演示课程。

## AI 辅助修复范围

本项目使用 AI 协助进行了代码审查、边界分析和工程化补全，主要修改包括：

1. 修复截止时间中 `0` 小时、`0` 分钟被错误当作默认值的问题。
2. 统一课程详情日历和签到率的日期口径，排除创建日前与未来日期。
3. 在页面/应用重新显示及每分钟刷新课程时钟，正确处理截止点和午夜切换。
4. 修复删除全部课程后重启又自动恢复演示数据的问题。
5. 在页面重新显示时重新同步主题导航栏和 tabBar。
6. 修正 Taro 输入框属性、抖音小程序输出目录及项目元数据。
7. 删除未接入且依赖缺失资源的云服务占位文件。
8. 增加类型检查、自动化逻辑测试、统一构建入口和项目说明。

AI 未重写原有 UI，也未引入远程服务。提交前仍应由开发者在目标设备或开发者工具中完成功能、布局和交互验收。

## 数据说明

当前版本为离线单用户应用，数据仅保存在运行端本地：

- `course_list_v1`：课程列表；
- `checkin_records_v2`：签到记录；
- `course_mock_init_v1`：演示数据初始化标记；
- `theme_id_v1`：当前主题。

清理浏览器站点数据或小程序本地缓存会删除这些数据。本项目没有登录、跨设备同步和云端备份功能。

## Git 与 Gitee 提交流程

当前目录若尚未初始化 Git，可在确认个人信息及提交内容后执行：

```bash
git init
git add .
git commit -m "feat: 完成课程签到系统实验"
git branch -M main
git remote add origin <GITEE_REPOSITORY_URL>
git push -u origin main
```

后续修改建议使用清晰的提交信息：

```bash
git add .
git commit -m "fix: 修复签到截止时间边界"
git push
```

### 仓库地址

- Gitee：`<请替换为你的 Gitee 仓库链接>`

请勿直接提交占位符。创建 Gitee 仓库后，将真实 HTTPS 地址同时填写到这里和实验报告中。

## 提交前检查清单

- [ ] `pnpm typecheck` 通过；
- [ ] `pnpm test` 全部通过；
- [ ] 至少完成一个目标端生产构建；
- [ ] 在开发者工具中验证新增、签到、删除、重置和主题切换；
- [ ] 替换游客 AppID 和 Gitee 链接占位符；
- [ ] 报告截图、代码版本和仓库提交保持一致。
