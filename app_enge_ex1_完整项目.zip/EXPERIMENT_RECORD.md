# 实验一过程与验证记录

## 实验目标

在现有课程签到系统上完成工程环境检查、Git 版本管理、README 编写、最小 Hello AI 程序、AI 辅助缺陷修复和运行验证。

## 环境

- Microsoft Windows 10.0.26200（25H2，x64）
- Node.js v24.20.0；pnpm 11.25.0
- Git 2.56.0.windows.1
- Taro 4.1.9、React 18、TypeScript 5
- 本地 H5 页面由静态服务器提供，浏览器验证签到首页、签到统计和课程管理页

## Git 操作记录

已初始化本地版本历史并提交完整课程签到系统。当前工作环境对项目目录中的 `.git` 元数据设置了写入拒绝，因此本次 Git 元数据保存在实验工作目录，并随提交材料提供 Git bundle，便于克隆恢复；项目源码本身位于原项目目录。

提交记录：

1. `feat: 完成课程签到系统与缺陷修复`
2. `docs: 记录实验过程与验证结果`

本实验未执行 Gitee push/pull：尚未提供个人 Gitee 仓库地址或远程仓库凭据。创建远程仓库后，使用以下命令完成推送与后续同步：

```bash
git clone app_enge_ex1_git.bundle app_enge_ex1
cd app_enge_ex1
git remote add origin <你的 Gitee 仓库 HTTPS 地址>
git push -u origin main
git pull --rebase origin main
```

## Hello AI

新增 `scripts/hello-ai.mjs`，运行结果：

```text
Hello, AI 编程！
课程签到系统工程环境已就绪。
可运行 pnpm test、pnpm typecheck 和 pnpm build 完成验证。
```

## AI 辅助分析和修复

AI 对签到日期、截止时间、持久化和页面恢复流程进行代码审查，发现并修复了以下问题：

1. 使用 `||` 处理截止时间，导致 `00` 小时或分钟被替换成默认值；
2. 课程创建日期之前和未来日期也会生成签到状态；
3. 删除全部课程后，应用重新启动又创建演示课程；
4. 页面恢复时课程时间状态和主题导航栏未及时同步；
5. Taro 输入属性、构建配置和抖音端输出目录存在不一致。

修复后新增课程服务边界测试。AI 建议由开发者通过类型检查、逻辑测试、生产构建和浏览器页面确认。

## 验证结果

- `node scripts/hello-ai.mjs`：通过。
- `node -r ts-node/register scripts/course-service.test.ts`：7/7 通过。
- `node_modules/.bin/tsc.cmd --noEmit`：通过。
- `taro build --type h5`：生产构建通过；构建输出包含资源体积提示，不影响构建完成。
- 浏览器检查：今日签到、签到记录、我的课程与主题页正常渲染。

## 提交前待办

- 填写实验报告封面的个人信息。
- 创建 Gitee 仓库并填写真实仓库 URL，完成 `git push` 和 `git pull` 演示。
- 根据课程要求，将小程序游客 AppID 替换为本人开发者账号对应 AppID。
- 在对应小程序开发者工具或目标设备完成交互验收。
